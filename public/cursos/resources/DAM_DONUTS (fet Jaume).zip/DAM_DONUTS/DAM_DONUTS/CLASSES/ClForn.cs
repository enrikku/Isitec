﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.Threading;
using System.Timers;

namespace DAM_DONUTS.CLASSES
{
    public class ClForn
    {
        private Mutex exclusioMutua = new Mutex();          // declarem aquesta variable per a poder accedir de manera única a un recurs

        private Form fpare;
        private System.Timers.Timer tmProduint = new System.Timers.Timer();
        private Panel pnl = new Panel();
        private PictureBox pbForn = new PictureBox();
        private PictureBox pbWait = new PictureBox();
        private PictureBox pbDonut = new PictureBox();
        private Label etqEstoc = new Label();
        private NumericUpDown nupSegons = new NumericUpDown();
        private Button btStartStop = new Button();

        private String textEstoc = "Estoc : ";
        private int estoc = 0;

        private delegate void Delegat();

        public ClForn(Form xpare, Point xpos)
        {
            fpare = xpare;

            iniPanell(xpos);
            iniTimer();
        }

        private void iniPanell(Point xpos)
        {

            pbForn.Location = new Point(0, 0);
            pbForn.Image = Properties.Resources.forn100;
            pbForn.Size = new Size(100, 100);
            pbForn.SizeMode = PictureBoxSizeMode.StretchImage;

            pbWait.Visible = false;
            pbWait.Image = Properties.Resources.wait002;
            pbWait.Size = new Size(100, 100);
            pbWait.SizeMode = PictureBoxSizeMode.StretchImage;
            pbWait.Location = new Point(pbForn.Right + 5, 0);

            pbDonut.Image = Properties.Resources.doughnut100;
            pbDonut.Size = new Size(40, 40);
            pbDonut.SizeMode = PictureBoxSizeMode.StretchImage;
            pbDonut.Location = new Point(pbWait.Right + 5, pbWait.Top+(pbDonut.Height/2));

            etqEstoc.Text = textEstoc + estoc.ToString();
            etqEstoc.Font = new Font("Verdana", 14);
            etqEstoc.AutoSize = true;
            etqEstoc.Location = new Point(pbDonut.Right + 5, pbForn.Top + (etqEstoc.Height / 2));
          
            btStartStop.Size = new Size(140, 36);
            btStartStop.Location = new Point(pbForn.Left+5,pbForn.Bottom + 10);
            btStartStop.Margin = new Padding(5);
            btStartStop.Text = "Start";
            btStartStop.BackColor = Color.Green;
            btStartStop.ForeColor = Color.White;
            btStartStop.Click += new EventHandler(EngegarAturar);

            nupSegons.Value = 1;
            nupSegons.Maximum = 20;
            nupSegons.Font = new Font("Verdana", 14);
            nupSegons.Size = new Size(58, 36);
            nupSegons.Location = new Point(btStartStop.Right + 10, btStartStop.Top);

            pnl.AutoSize = true;
            pnl.Location = xpos;
            pnl.BorderStyle = BorderStyle.FixedSingle;

            pnl.Controls.Add(pbForn);
            pnl.Controls.Add(pbWait);
            pnl.Controls.Add(pbDonut);
            pnl.Controls.Add(etqEstoc);
            pnl.Controls.Add(btStartStop);
            pnl.Controls.Add(nupSegons);
            fpare.Controls.Add(pnl);
        }

        private void iniTimer()
        {
            tmProduint.Elapsed += new System.Timers.ElapsedEventHandler(nouDonut);
        }

        public void Cuinar()
        {
            // aquest mètode no caldria però el posem per a mantenir
            // la simetria amb els exemples i les altres pràctiques
            if (btStartStop.BackColor == Color.Red)
            {
                tmProduint.Start();
            }
        }

        private void nouDonut(object sender, ElapsedEventArgs e)
        {
            Delegat encarregat = updEtqEstoc;

            exclusioMutua.WaitOne();
            estoc++;
            pnl.Invoke(encarregat);
            exclusioMutua.ReleaseMutex();
        }

        public int quantEstoc()
        {
            return estoc;
        }

        public void restarEstoc(int n)
        {
            Delegat encarregat = updEtqEstoc;

            exclusioMutua.WaitOne();
            estoc-=n;
            pnl.Invoke(encarregat);
            exclusioMutua.ReleaseMutex();
        }

        private void updEtqEstoc()
        {
            etqEstoc.Text = textEstoc + estoc.ToString();
            etqEstoc.Refresh();
         }

        private void EngegarAturar(object sender, EventArgs e)
        {
            if (btStartStop.Text=="Start")
            {
                pbWait.Visible = true;
                btStartStop.Text = "Stop";
                btStartStop.BackColor = Color.Red;
                nupSegons.Enabled = false;
                tmProduint.Interval = (Int32) nupSegons.Value * 1000;
                tmProduint.Start();
            } else
            {
                pbWait.Visible = false;
                btStartStop.Text = "Start";
                btStartStop.BackColor = Color.Green;
                nupSegons.Enabled = true;
                tmProduint.Stop();
            }
        }

        public void Aturar()
        {
            tmProduint.Stop();
        }
    }
}
