﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using DAM_DONUTS.CLASSES;

namespace DAM_DONUTS
{
    public partial class FrmMain : Form
    {
        private const int NGOLAFRES = 2;
        private const int NFORNS = 7;
        private const int FORNSxFILA = 4;
        private const int GOLAFRESxFILA = 5;

        private Mutex exclusioMutua = new Mutex();

        public int quantsDonuts = 0;

        private List<ClGolafre> llGolafres = new List<ClGolafre>();
        private List<ClForn> llForns = new List<ClForn>();

        List<Thread> llThForns = new List<Thread>();
        List<Thread> llThGolafres = new List<Thread>();
 
        public FrmMain()
        {
            InitializeComponent();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            iniForns();
            iniGolafres();
        }

        private void iniGolafres()
        {
            Point p;

            int w = (this.Width - 600) / GOLAFRESxFILA;

            for (int i = 0; i < NGOLAFRES; i++)
            {
                p=new Point(50 + (w + 100) * (i % GOLAFRESxFILA), this.Height - 400 + (i / GOLAFRESxFILA) * 150);
                llGolafres.Add(new ClGolafre(this, p));
                llThGolafres.Add(new Thread(llGolafres[llGolafres.Count - 1].Menjar));
                llThGolafres[llThGolafres.Count - 1].Start();
            }
        }
        
        private void iniForns()
        {
            Point p;
            int w = (this.Width - 400) / FORNSxFILA;

            for (int i = 0; i < NFORNS; i++)
            {
                p=new Point(5 + (w + 100) * (i % FORNSxFILA), 10 + (i / FORNSxFILA) * 200);
                llForns.Add(new ClForn(this, p));
                llThForns.Add(new Thread(llForns[llForns.Count - 1].Cuinar));
                llThForns[llThForns.Count - 1].Start();
           }

        }

        private void FrmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            foreach (ClForn f in llForns)
            {
                f.Aturar();
            }

            foreach (Thread th in llThGolafres)
            {
                if (th.IsAlive)
                {
                    th.Abort();
                }
            }
        }

        public Boolean donarDonut()
        {
            Boolean xb = false;
            int i = 0;

            exclusioMutua.WaitOne();
            while ((i < llForns.Count) && !xb)
            {
                if (llForns[i].quantEstoc() > 0)
                {
                    llForns[i].restarEstoc(1);
                    xb = true;
                }
            }
            exclusioMutua.ReleaseMutex();
            return xb;

        }
    }
}
