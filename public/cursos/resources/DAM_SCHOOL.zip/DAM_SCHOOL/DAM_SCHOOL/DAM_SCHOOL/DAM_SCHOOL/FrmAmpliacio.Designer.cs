﻿namespace DAM_SCHOOL
{
    partial class FrmAmpliacio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lbHdr = new System.Windows.Forms.Label();
            this.dgDades = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgDades)).BeginInit();
            this.SuspendLayout();
            // 
            // lbHdr
            // 
            this.lbHdr.AutoSize = true;
            this.lbHdr.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.lbHdr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbHdr.Location = new System.Drawing.Point(12, 13);
            this.lbHdr.MaximumSize = new System.Drawing.Size(678, 2);
            this.lbHdr.MinimumSize = new System.Drawing.Size(678, 25);
            this.lbHdr.Name = "lbHdr";
            this.lbHdr.Size = new System.Drawing.Size(678, 25);
            this.lbHdr.TabIndex = 10;
            this.lbHdr.Text = "Estudiants";
            this.lbHdr.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgDades
            // 
            this.dgDades.AllowUserToAddRows = false;
            this.dgDades.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Yellow;
            this.dgDades.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgDades.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgDades.BackgroundColor = System.Drawing.Color.PaleGoldenrod;
            this.dgDades.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgDades.Location = new System.Drawing.Point(12, 44);
            this.dgDades.Name = "dgDades";
            this.dgDades.ReadOnly = true;
            this.dgDades.RowHeadersVisible = false;
            this.dgDades.RowHeadersWidth = 51;
            this.dgDades.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgDades.ShowEditingIcon = false;
            this.dgDades.Size = new System.Drawing.Size(678, 500);
            this.dgDades.TabIndex = 9;
            // 
            // FrmAmpliacio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.ClientSize = new System.Drawing.Size(702, 556);
            this.Controls.Add(this.lbHdr);
            this.Controls.Add(this.dgDades);
            this.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "FrmAmpliacio";
            this.Text = "FrmAmpliacio";
            this.Load += new System.EventHandler(this.FrmAmpliacio_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgDades)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbHdr;
        private System.Windows.Forms.DataGridView dgDades;
    }
}