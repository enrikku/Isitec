﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAM_SCHOOL.MODELS;

namespace DAM_SCHOOL
{
    public partial class FrmAmpliacio : Form
    {
        private SchoolEntities schoolContext = new SchoolEntities();       // necessitem una instància del Context
        public Course curs;

        public FrmAmpliacio()
        {
            InitializeComponent();
        }

        private void FrmAmpliacio_Load(object sender, EventArgs e)
        {
            consultaEstudiants();
        }

        private void consultaEstudiants()
        {
            // declarem una consulta de tots els Departaments, utilitzem llenguatge LINQ
            var qryEstudiants = (from Estudiants in schoolContext.StudentGrade
                                 where Estudiants.CourseID == curs.CourseID
                                 orderby Estudiants.Person.LastName
                                 select new
                                 {
                                     nom = Estudiants.Person.FirstName,
                                     cognoms = Estudiants.Person.LastName,
                                 });

            dgDades.DataSource = qryEstudiants.ToList().Distinct().ToList();

        }

        private void consultaCompleta()
        {
            // declarem una consulta de tots els Departaments, utilitzem llenguatge LINQ
            var qryEstudiants = (from Estudiants in schoolContext.StudentGrade
                                 orderby Estudiants.Person.LastName
                                 select new
                                 {
                                     id = Estudiants.Person.PersonID,
                                     nom = Estudiants.Person.FirstName,
                                     cognoms = Estudiants.Person.LastName,
                                 }).Distinct();

            dgDades.DataSource = qryEstudiants.ToList();

        }
    }
    }
