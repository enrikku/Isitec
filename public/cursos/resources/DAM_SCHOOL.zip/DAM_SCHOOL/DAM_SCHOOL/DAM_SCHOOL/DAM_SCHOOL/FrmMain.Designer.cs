﻿namespace DAM_SCHOOL
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.dgDades = new System.Windows.Forms.DataGridView();
            this.lbDepartament = new System.Windows.Forms.Label();
            this.cbDepartaments = new System.Windows.Forms.ComboBox();
            this.lbHdr = new System.Windows.Forms.Label();
            this.lbTitol = new System.Windows.Forms.Label();
            this.tbTitol = new System.Windows.Forms.TextBox();
            this.gbCurs = new System.Windows.Forms.GroupBox();
            this.btUpdate = new System.Windows.Forms.Button();
            this.tbId = new System.Windows.Forms.TextBox();
            this.lbId = new System.Windows.Forms.Label();
            this.btNew = new System.Windows.Forms.Button();
            this.tbCredits = new System.Windows.Forms.TextBox();
            this.lbCredits = new System.Windows.Forms.Label();
            this.btBaixa = new System.Windows.Forms.Button();
            this.btEstudiants = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgDades)).BeginInit();
            this.gbCurs.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgDades
            // 
            this.dgDades.AllowUserToAddRows = false;
            this.dgDades.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Yellow;
            this.dgDades.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgDades.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgDades.BackgroundColor = System.Drawing.Color.PaleGoldenrod;
            this.dgDades.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgDades.Location = new System.Drawing.Point(12, 91);
            this.dgDades.Name = "dgDades";
            this.dgDades.ReadOnly = true;
            this.dgDades.RowHeadersVisible = false;
            this.dgDades.RowHeadersWidth = 51;
            this.dgDades.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgDades.ShowEditingIcon = false;
            this.dgDades.Size = new System.Drawing.Size(400, 450);
            this.dgDades.TabIndex = 7;
            // 
            // lbDepartament
            // 
            this.lbDepartament.AutoSize = true;
            this.lbDepartament.Location = new System.Drawing.Point(15, 24);
            this.lbDepartament.Name = "lbDepartament";
            this.lbDepartament.Size = new System.Drawing.Size(114, 18);
            this.lbDepartament.TabIndex = 6;
            this.lbDepartament.Text = "Departaments";
            // 
            // cbDepartaments
            // 
            this.cbDepartaments.FormattingEnabled = true;
            this.cbDepartaments.Location = new System.Drawing.Point(118, 21);
            this.cbDepartaments.Name = "cbDepartaments";
            this.cbDepartaments.Size = new System.Drawing.Size(303, 26);
            this.cbDepartaments.TabIndex = 5;
            this.cbDepartaments.SelectedIndexChanged += new System.EventHandler(this.cbDepartaments_SelectedIndexChanged);
            // 
            // lbHdr
            // 
            this.lbHdr.AutoSize = true;
            this.lbHdr.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.lbHdr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbHdr.Location = new System.Drawing.Point(12, 60);
            this.lbHdr.MaximumSize = new System.Drawing.Size(400, 2);
            this.lbHdr.MinimumSize = new System.Drawing.Size(400, 25);
            this.lbHdr.Name = "lbHdr";
            this.lbHdr.Size = new System.Drawing.Size(400, 25);
            this.lbHdr.TabIndex = 8;
            this.lbHdr.Text = "Cursos disponibles";
            this.lbHdr.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbTitol
            // 
            this.lbTitol.AutoSize = true;
            this.lbTitol.Location = new System.Drawing.Point(162, 24);
            this.lbTitol.Name = "lbTitol";
            this.lbTitol.Size = new System.Drawing.Size(75, 18);
            this.lbTitol.TabIndex = 9;
            this.lbTitol.Text = "Títol curs";
            // 
            // tbTitol
            // 
            this.tbTitol.Location = new System.Drawing.Point(231, 21);
            this.tbTitol.MaxLength = 20;
            this.tbTitol.Name = "tbTitol";
            this.tbTitol.Size = new System.Drawing.Size(183, 26);
            this.tbTitol.TabIndex = 10;
            // 
            // gbCurs
            // 
            this.gbCurs.Controls.Add(this.btUpdate);
            this.gbCurs.Controls.Add(this.tbId);
            this.gbCurs.Controls.Add(this.lbId);
            this.gbCurs.Controls.Add(this.btNew);
            this.gbCurs.Controls.Add(this.tbCredits);
            this.gbCurs.Controls.Add(this.lbCredits);
            this.gbCurs.Controls.Add(this.tbTitol);
            this.gbCurs.Controls.Add(this.lbTitol);
            this.gbCurs.Location = new System.Drawing.Point(12, 548);
            this.gbCurs.Name = "gbCurs";
            this.gbCurs.Size = new System.Drawing.Size(800, 57);
            this.gbCurs.TabIndex = 11;
            this.gbCurs.TabStop = false;
            this.gbCurs.Text = " ";
            // 
            // btUpdate
            // 
            this.btUpdate.BackColor = System.Drawing.Color.Tan;
            this.btUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btUpdate.Location = new System.Drawing.Point(691, 14);
            this.btUpdate.Name = "btUpdate";
            this.btUpdate.Size = new System.Drawing.Size(88, 37);
            this.btUpdate.TabIndex = 17;
            this.btUpdate.Text = "Modificar";
            this.btUpdate.UseVisualStyleBackColor = false;
            this.btUpdate.Click += new System.EventHandler(this.btUpdate_Click);
            // 
            // tbId
            // 
            this.tbId.Location = new System.Drawing.Point(47, 21);
            this.tbId.MaxLength = 5;
            this.tbId.Name = "tbId";
            this.tbId.Size = new System.Drawing.Size(91, 26);
            this.tbId.TabIndex = 16;
            // 
            // lbId
            // 
            this.lbId.AutoSize = true;
            this.lbId.Location = new System.Drawing.Point(17, 24);
            this.lbId.Name = "lbId";
            this.lbId.Size = new System.Drawing.Size(27, 18);
            this.lbId.TabIndex = 15;
            this.lbId.Text = "Id.";
            // 
            // btNew
            // 
            this.btNew.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.btNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btNew.Location = new System.Drawing.Point(591, 13);
            this.btNew.Name = "btNew";
            this.btNew.Size = new System.Drawing.Size(75, 37);
            this.btNew.TabIndex = 13;
            this.btNew.Text = "Inserir";
            this.btNew.UseVisualStyleBackColor = false;
            this.btNew.Click += new System.EventHandler(this.btNew_Click);
            // 
            // tbCredits
            // 
            this.tbCredits.Location = new System.Drawing.Point(488, 21);
            this.tbCredits.MaxLength = 2;
            this.tbCredits.Name = "tbCredits";
            this.tbCredits.Size = new System.Drawing.Size(38, 26);
            this.tbCredits.TabIndex = 12;
            // 
            // lbCredits
            // 
            this.lbCredits.AutoSize = true;
            this.lbCredits.Location = new System.Drawing.Point(430, 24);
            this.lbCredits.Name = "lbCredits";
            this.lbCredits.Size = new System.Drawing.Size(60, 18);
            this.lbCredits.TabIndex = 11;
            this.lbCredits.Text = "Crèdits";
            // 
            // btBaixa
            // 
            this.btBaixa.BackColor = System.Drawing.Color.Tomato;
            this.btBaixa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btBaixa.Location = new System.Drawing.Point(432, 494);
            this.btBaixa.Name = "btBaixa";
            this.btBaixa.Size = new System.Drawing.Size(150, 37);
            this.btBaixa.TabIndex = 14;
            this.btBaixa.Text = "Eliminar seleccionat";
            this.btBaixa.UseVisualStyleBackColor = false;
            this.btBaixa.Click += new System.EventHandler(this.btBaixa_Click);
            // 
            // btEstudiants
            // 
            this.btEstudiants.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btEstudiants.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btEstudiants.Location = new System.Drawing.Point(445, 91);
            this.btEstudiants.Name = "btEstudiants";
            this.btEstudiants.Size = new System.Drawing.Size(125, 37);
            this.btEstudiants.TabIndex = 15;
            this.btEstudiants.Text = "Estudiants";
            this.btEstudiants.UseVisualStyleBackColor = false;
            this.btEstudiants.Click += new System.EventHandler(this.btEstudiants_Click);
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.ClientSize = new System.Drawing.Size(825, 617);
            this.Controls.Add(this.btEstudiants);
            this.Controls.Add(this.gbCurs);
            this.Controls.Add(this.lbHdr);
            this.Controls.Add(this.btBaixa);
            this.Controls.Add(this.dgDades);
            this.Controls.Add(this.lbDepartament);
            this.Controls.Add(this.cbDepartaments);
            this.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "FrmMain";
            this.Text = "School";
            this.Load += new System.EventHandler(this.FrmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgDades)).EndInit();
            this.gbCurs.ResumeLayout(false);
            this.gbCurs.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgDades;
        private System.Windows.Forms.Label lbDepartament;
        private System.Windows.Forms.ComboBox cbDepartaments;
        private System.Windows.Forms.Label lbHdr;
        private System.Windows.Forms.Label lbTitol;
        private System.Windows.Forms.TextBox tbTitol;
        private System.Windows.Forms.GroupBox gbCurs;
        private System.Windows.Forms.Button btNew;
        private System.Windows.Forms.TextBox tbCredits;
        private System.Windows.Forms.Label lbCredits;
        private System.Windows.Forms.Button btBaixa;
        private System.Windows.Forms.TextBox tbId;
        private System.Windows.Forms.Label lbId;
        private System.Windows.Forms.Button btUpdate;
        private System.Windows.Forms.Button btEstudiants;
    }
}

