﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using DAM_SCHOOL.MODELS;

namespace DAM_SCHOOL
{
    public partial class FrmMain : Form
    {

        private SchoolEntities schoolContext=new SchoolEntities();       // necessitem una instància del Context

        public FrmMain()
        {
            InitializeComponent();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            // declarem una consulta de tots els Departaments, utilitzem llenguatge LINQ
            var qryDepartaments = from dpt in schoolContext.Department
                                  orderby dpt.Name
                                  select dpt;
            

           // omplim el combobox de departaments
           cbDepartaments.DisplayMember = "Name";
            cbDepartaments.ValueMember = "DepartmenID";
            cbDepartaments.DataSource = qryDepartaments.ToList();
        }

        private void cbDepartaments_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbDepartaments.SelectedItem != null)
            {
                consultarCursos(((Department)cbDepartaments.SelectedItem).Name);
                //MessageBox.Show("DepartmentID : "+((Department)cbDepartaments.SelectedValue).DepartmentID.ToString());
            }

        }

        private void consultarCursos(String xdepart)
        {
            // declarem una consulta dels Cursos del Departament seleccionat
            var qryCursos = from c in schoolContext.Course
                            where c.Department.Name == xdepart
                            orderby c.Title
                            select new
                            {
                                id = c.CourseID,
                                titol = c.Title,
                                credits = c.Credits
                            };

            // omplim el datagridview
            dgDades.DataSource = qryCursos.ToList();
        }

        // inserir nou curs
        private void btNew_Click(object sender, EventArgs e)
        {
            Course curs = new Course();

            this.Cursor = Cursors.WaitCursor;

            if ((tbId.Text.Trim() == "") || (tbTitol.Text.Trim()=="") || (tbCredits.Text.Trim() == ""))
            {
                MessageBox.Show("Has d'omplir totes les dades", "Informació", MessageBoxButtons.OK, MessageBoxIcon.Information);
            } else
            {
                // tractem la taula de cursos com una classe d'objecte
                curs.CourseID = Convert.ToInt32(tbId.Text.Trim());
                curs.Title = tbTitol.Text.Trim();
                curs.Credits = Convert.ToInt32(tbCredits.Text.Trim());
                curs.DepartmentID = ((Department)cbDepartaments.SelectedItem).DepartmentID;

                schoolContext.Course.Add(curs);     // la inserció esdevé una crida a Add

                try
                {
                    schoolContext.SaveChanges();        // la inserció no es fa efectiva fins que fem el SaveChanges
                } catch (Exception excp)
                {
                    MessageBox.Show(excp.Message+Environment.NewLine+excp.InnerException, "Excepció", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    schoolContext.Course.Remove(curs);     // eliminem la instància que ha provocat l'error per a que no quedi a la cua
                }
                consultarCursos(((Department)cbDepartaments.SelectedItem).Name);
            }
            this.Cursor = Cursors.Default;
        }

        // suprimir curs
        private void btBaixa_Click(object sender, EventArgs e)
        {
            int idCurs=-1;
            Course curs=null;

            if (dgDades.SelectedRows.Count > 0)
            {
                this.Cursor = Cursors.WaitCursor;
                idCurs = Convert.ToInt32(dgDades.SelectedRows[0].Cells[0].Value);   // agafem la clau primària
                curs = schoolContext.Course.Find(idCurs);                           // busquem a la taula de cursos per clau primària
                schoolContext.Course.Remove(curs);                                  // eliminem 

                try
                {
                    schoolContext.SaveChanges();        // l'eliminació no es fa efectiva fins que fem el SaveChanges
                }
                catch (Exception excp)
                {
                    MessageBox.Show(excp.Message + Environment.NewLine + excp.InnerException, "Excepció", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                consultarCursos(((Department)cbDepartaments.SelectedItem).Name);
                this.Cursor = Cursors.Default;
            }
            else
                MessageBox.Show("Cal seleccionar algun curs", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            {

            }
        }

        // modificar curs
        private void btUpdate_Click(object sender, EventArgs e)
        {
            int idCurs=-1;
            Course curs =null;

            this.Cursor = Cursors.WaitCursor;

            if ((tbId.Text.Trim() == "") || (tbTitol.Text.Trim() == "") || (tbCredits.Text.Trim() == ""))
            {
                MessageBox.Show("Has d'omplir totes les dades", "Informació", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                idCurs = Convert.ToInt32(tbId.Text.Trim());   
                curs = schoolContext.Course.Find(idCurs);     
                
                curs.Title = tbTitol.Text.Trim();
                curs.Credits = Convert.ToInt32(tbCredits.Text.Trim());
                curs.DepartmentID = ((Department)cbDepartaments.SelectedItem).DepartmentID;

                try
                {
                    schoolContext.SaveChanges();        // la modificació no es fa efectiva fins que fem el SaveChanges
                }
                catch (Exception excp)
                {
                    MessageBox.Show(excp.Message + Environment.NewLine + excp.InnerException, "Excepció", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                consultarCursos(((Department)cbDepartaments.SelectedItem).Name);
            }
            this.Cursor = Cursors.Default;

        }

        private void btEstudiants_Click(object sender, EventArgs e)
        {
            int idCurs = -1;

            FrmAmpliacio frmAmpliacio = new FrmAmpliacio();
            idCurs = Convert.ToInt32(dgDades.SelectedRows[0].Cells[0].Value);   // agafem la clau primària

            frmAmpliacio.curs= schoolContext.Course.Find(idCurs);
            frmAmpliacio.ShowDialog();
        }
    }
}
