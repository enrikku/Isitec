import React from "react";
import { useRoutes } from "react-router-dom";
import Home from "pages/Home";
import NotFound from "pages/NotFound";
import Cart from "pages/Cart";
import Homepage from "pages/Homepage";

const ProjectRoutes = () => {
  let element = useRoutes([
    { path: "dhiwise-dashboard", element: <Home /> },
    { path: "*", element: <NotFound /> },
    {
      path: "/",
      element: <Cart />,
    },
    {
      path: "homepage",
      element: <Homepage />,
    },
  ]);

  return element;
};

export default ProjectRoutes;
