import React from "react";

const sizes = {
  "3xl": "text-[40px] font-bold leading-[60px]",
  "2xl": "text-4xl font-bold",
  xl: "text-[32px] font-bold",
  s: "text-lg font-semibold",
  md: "text-xl font-semibold",
  xs: "text-base font-bold leading-[19px]",
  lg: "text-2xl font-bold",
};

export type HeadingProps = Partial<{
  className: string;
  as: any;
  size: keyof typeof sizes;
}> &
  React.DetailedHTMLProps<React.HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>;

const Heading: React.FC<React.PropsWithChildren<HeadingProps>> = ({
  children,
  className = "",
  size = "md",
  as,
  ...restProps
}) => {
  const Component = as || "h6";

  return (
    <Component className={`text-black-900 font-raleway ${className} ${sizes[size]}`} {...restProps}>
      {children}
    </Component>
  );
};

export { Heading };
