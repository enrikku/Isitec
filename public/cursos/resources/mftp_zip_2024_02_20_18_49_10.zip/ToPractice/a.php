<?php
header("Access-Control-Allow-Origin: *");
header('Content-Type: application/json');


    $request_body = file_get_contents('php://input');
    $data = json_decode($request_body, true);

echo var_dump($request_body);