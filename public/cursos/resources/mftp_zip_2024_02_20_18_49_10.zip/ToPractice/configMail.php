<?php
use PHPMailer\PHPMailer\PHPMailer;
require __DIR__.'/../vendor/autoload.php';

function configMail()
{

    $mail = new PHPMailer(); // Crea una nueva instancia de la clase PHPMailer
    $mail->IsSMTP(); // Establece el uso de SMTP para enviar el correo

    $mail->SMTPDebug = 0; // Desactiva la depuración detallada de SMTP (0 = off, 1 = client messages, 2 = client and server messages)

    $mail->Host = "smtp.dondominio.com"; // Define el host del servidor SMTP. Debe ser configurado.

    $mail->Username = "isitec@isitec.cat"; // Define el nombre de usuario para la autenticación SMTP

    $mail->Password = "1234567Aa#"; // Define la contraseña para la autenticación SMTP

    $mail->CharSet = 'UTF-8'; // Establece el conjunto de caracteres a UTF-8

    $mail->SMTPAuth = true; // Activa la autenticación SMTP

    $mail->Port = 587; // Establece el puerto TCP para conectar al servidor SMTP

    $SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Establece el tipo de encriptación en STARTTLS
    $mail->SMTPSecure = $SMTPSecure; // Aplica la encriptación STARTTLS

    $mail->Host = "smtp.dondominio.com"; // Define el host del servidor SMTP (debería tener un nombre de dominio válido)

    $mail->SetFrom("isitec@isitec.cat", "Isitec"); // Establece la dirección del remitente y el nombre (opcional)

    $mail->Subject = "Isitec"; // Define el asunto del correo

    $mail->CharSet = 'UTF-8'; // Establece nuevamente el conjunto de caracteres a UTF-8 (esta línea es redundante)

    $mail->AddAddress("isitec@isitec.cat"); // Añade una dirección de destinatario (debería incluir un correo electrónico válido)

    return $mail;

}
