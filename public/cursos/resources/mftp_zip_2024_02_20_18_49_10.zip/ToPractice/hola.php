<?php
require_once __DIR__ . '/configMail.php';

header("Access-Control-Allow-Origin: *");
header('Content-Type: application/json');


$email = $_POST["email"]; // correo del usuario
$error = "";

if(isset($email)){
    $m = configMail();

    $msg = "hola";

    $m->Body = $msg;
    $m->IsHTML(true);
    //$m->SMTPDebug = 2;
    $m->AddAddress($email);
    
    if (!$m->send()) {
        $error =  'El mensaje no se pudo enviar. Error del mailer';
    } else {
        $error = 'El mensaje ha sido enviado';
    }
}
else
{
    //$error = "No email submit";
    $error = var_dump($_POST);
}


$data = array(
    "email" => $email,
    "error" => $error,
    
);
$json_data = json_encode($data);

echo $json_data;
?>
